#include<iostream>
#include<string>
#include<cmath>

using namespace std;
/*
void elements_operations(int arr[], int c){

    for(int i=2;i<=c;i++){

    }

}
*/

int eratosthenes(long long int x){
   long long int i=2;

   while((i*i) <= x){
    for(long long int j=2;j<=x;j++){
        if(i*j == x) return 1;
        else if(i*j > x) break;
    }
    i++;
   }

   /*
if(x>500000){/*
int tmp=x, cnt=1, rst=0, ptr=0;
cond=1;
while(tmp>500000){tmp-500000;cnt++;}
int num[cnt][500000];
for(int i=0;i<x-1;i++){
        if(rst>500000){ptr++;rst=0;}
        num[ptr][rst]=i;
        rst++;
        }

int i=2, row=0, clm=0, w=1;
//if(num[i]!=-1)
while((i*i) <= x){
    for(int j=2;j<=x;j++){
            clm=i%500000;
        if((num[row][clm]*j) < x) num[row][num[row][clm]*j]=-1;
        else if((num[row][clm]*j) == x) return 1;
        else break;
    }
    i++;
    if(i>500000*w){row++;w}}
return 0;*/

/*
} //return 0;
else{ int num[x-1];for(int i=0;i<x-1;i++){num[i]=i+2;}

int i=2;
if(num[i-2]!=-1)
while((i*i) <= x){
    for(int j=2;j<=x;j++){
        if((num[i-2]*j) < x) num[num[i-2]*j]=-1;
        else if((num[i-2]*j) == x) return 1;
        else break;
    }
    i++;
}
}*/
return 0;
}

int main(){

    long long int x, r, tmp, save, res1, res2;
    int c, i=0;

//while(1){
    cout<<"Define Galois field GF(p)"<<endl<<endl<<"p = ";
    while(1){
    cin>>x;
    if(eratosthenes(x)!=0){cout<<"Your input is not prime number, try again."<<endl<<endl<<"p = ";cin.clear();cin.sync();}
    else break;
    }
    cout<<endl<<"How many input elements?"<<endl;
    cin>>c;
    int input[c];

    cout<<endl<<"Write in input elements"<<endl;
    while(i<c){
    cin>>input[i];
    if(input[i]<0 || input[i]>=x){cout<<"This number is not part of GF("<<x<<"), try again."<<endl;cin.clear();cin.sync();continue;}
    cin.clear();cin.sync();
    i++;
    }

    //long long int r, tmp, save;
    cout<<endl<<"Addition of elements:"<<endl;
    r=0;for(i=0;i<c;i++){r+=input[i];r=r%x;res1=r;} cout<<r<<endl<<endl;

    cout<<"Multiplication of elements:"<<endl;
    r=input[0];for(i=1;i<c;i++){r=r*input[i];r=r%x;res2=r;} cout<<r<<endl<<endl; if(c==1) res2=input[0];

    cout<<"Inverse elements in addition:"<<endl;
    for(i=0;i<c;i++){
       if(input[i]==0){cout<<"<0> = <0>"<<endl; continue;}
       r=x-input[i];
       cout<<"<"<<input[i]<<">"<<" = <"<<r<<">"<<endl;
    }
    cout<<endl<<"For arithmetics operations results:"<<endl;
    if(res1==0){cout<<"<0> = <0>"<<endl;}
    else{r=x-res1; cout<<"<"<<res1<<">"<<" = <"<<r<<">"<<endl;}
    if(res2==0){cout<<"<0> = <0>"<<endl;}
    else{r=x-res2; cout<<"<"<<res2<<">"<<" = <"<<r<<">"<<endl;}

    cout<<endl<<"Inverse elements in multiplication:"<<endl;
    for(i=0;i<c;i++){
        tmp=input[i];
        if(tmp==0){cout<<"0 does not have inverse element"<<endl;continue;}
       while(1){
            save=tmp;
            tmp=(input[i]*tmp)%x;
            if(tmp==1){r=save;break;}
       }
       cout<<"<"<<input[i]<<">"<<" = <"<<r<<">"<<endl;
    }
    cout<<endl<<"For arithmetics operations results:"<<endl;
    if(res1==0){cout<<"0 does not have inverse element"<<endl;}
    else{tmp=res1;while(1){save=tmp;tmp=(res1*tmp)%x;if(tmp==1){r=save;break;}}cout<<"<"<<res1<<">"<<" = <"<<r<<">"<<endl;}
    if(res2==0){cout<<"0 does not have inverse element"<<endl;}
    else{tmp=res2;while(1){save=tmp;tmp=(res2*tmp)%x;if(tmp==1){r=save;break;}}cout<<"<"<<res2<<">"<<" = <"<<r<<">"<<endl;}

    cout<<endl<<endl;
//}
system("pause");
return 0;
}
